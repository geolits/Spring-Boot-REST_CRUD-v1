package com.example.demo.Match;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "api/v1/match")
public class MatchController {

    private final MatchService matchService;

    @Autowired //DI
    public MatchController(MatchService matchService) {
        this.matchService = matchService;
    }

    @GetMapping
    public ResponseEntity<List<Match>> getMatches(){
       List<Match> matchList= matchService.getMatches();
        return new ResponseEntity<>(matchList, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Match> getMatchById(@PathVariable Long id){
        //System.out.println(id);
        //Optional<Match> matchOptional= matchService.getMatchById(id);
        return  new ResponseEntity<>(matchService.getMatchById(id), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Match> addNewMatch(@RequestBody Match match){
        return  new ResponseEntity<>(matchService.addNewMatch(match), HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Match> updateMatch(@PathVariable Long id, @RequestBody Match match){

        Match updatedMatch = matchService.updateMatchById(id, match);

        return  new ResponseEntity<>(updatedMatch, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public Map<String, Boolean> deleteMatch(@PathVariable Long id){

        Match match = matchService.deleteMatchById(id);

        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Match> updateMatchPartially(@PathVariable Long id, @RequestBody String description) {

        Match match = matchService.updateMatchDescription(id, description);

        return new ResponseEntity<Match>(match, HttpStatus.OK);

    }


   /* @GetMapping
    public String getMatches(){
        return matchService.getMatches();
    }*/
}
