package com.example.demo.MatchOdds;

import com.example.demo.Match.Match;
import com.example.demo.Match.MatchRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

@Service
public class MatchOddService {

    private final MatchOddRepository matchOddRepository;
    private final MatchRepository matchRepository;

    @Autowired
    public MatchOddService(MatchOddRepository matchOddRepository, MatchRepository matchRepository) {
        this.matchOddRepository = matchOddRepository;
        this.matchRepository = matchRepository;
    }

    public List<MatchOdd> getMatchOdds(){
        return matchOddRepository.findAll();
    }

    public MatchOdd getMatchOddById(Long id){
        Optional<MatchOdd> matchOddOptional = matchOddRepository.findById(id);

        if (matchOddOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, String.format("Match Odd with id %d not found", id));
        }

        return matchOddOptional.get();
    }


    public MatchOdd addNewMatchOdd(MatchOdd matchOdd){

       Optional<Match> matchOptional = matchRepository.findById(matchOdd.getMatch().getId());

        if (matchOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, String.format("The Match with id %d not found", matchOdd.getMatch().getId()));
        }

        System.out.println("The Match Odd has been added");
        return matchOddRepository.save(matchOdd);
    }

    public MatchOdd updateMatchOddById(Long id, MatchOdd matchOdd){
        Optional<MatchOdd> matchOddOptional = matchOddRepository.findById(id);

        if (matchOddOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, String.format("The Match Odd with id %d not found", id));
        }

        MatchOdd updatedMatchOdd = matchOddOptional.get();

        updatedMatchOdd.setSpecifier(matchOdd.getSpecifier());
        updatedMatchOdd.setOdd(matchOdd.getOdd());
        updatedMatchOdd.setMatch(matchOdd.getMatch());

        updatedMatchOdd = matchOddRepository.save(updatedMatchOdd);

        return updatedMatchOdd;
    }

    public MatchOdd deleteMatchOddById(Long id){
        Optional<MatchOdd> matchOddOptional = matchOddRepository.findById(id);

        if (matchOddOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, String.format("MatchOdd with id %d not found", id));
        }

        matchOddRepository.deleteById(id);

        return matchOddOptional.get();
    }

    public MatchOdd updateMatchOddOddPercentage(Long id, double oddPercentage){

        Optional<MatchOdd> matchOddOptional = matchOddRepository.findById(id);

        if (matchOddOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, String.format("Match Odd with id %d not found", id));
        }

        matchOddOptional.get().setOdd(oddPercentage);
        matchOddRepository.save(matchOddOptional.get());

        return matchOddOptional.get();
    }


}
