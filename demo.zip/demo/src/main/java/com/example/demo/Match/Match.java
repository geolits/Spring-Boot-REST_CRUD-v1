package com.example.demo.Match;

import com.example.demo.MatchOdds.MatchOdd;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "match")
public class Match {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(name="description")
    private String description;
    @Column(name="match_date")
    private LocalDate match_date;
    @Column(name="team_a")
    private String team_a;
    @Column(name="team_b")
    private String team_b;
    @Column(name="sport")
    private SportType sport;

    //@JsonManagedReference
    @OneToMany(
            mappedBy = "match",
            cascade = CascadeType.ALL,
            orphanRemoval = true    )
    private List<MatchOdd> matchOdds = new ArrayList<>();

    public Match() {

    }

    public Match(Long id, String description, LocalDate match_date, String team_a, String team_b, SportType sport) {
        this.id = id;
        this.description = description;
        this.match_date = match_date;
        this.team_a = team_a;
        this.team_b = team_b;
        this.sport = sport;
    }

    public Match(String description, LocalDate match_date, String team_a, String team_b, SportType sport) {
        this.description = description;
        this.match_date = match_date;
        this.team_a = team_a;
        this.team_b = team_b;
        this.sport = sport;
    }


    public void setMatchOdds(List<MatchOdd> matchOdds) {
        this.matchOdds = matchOdds;
    }

    public List<MatchOdd> getMatchOdds(){
        return matchOdds;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getMatch_date() {
        return match_date;
    }

    public void setMatch_date(LocalDate match_date) {
        this.match_date = match_date;
    }

    public String getTeam_a() {
        return team_a;
    }

    public void setTeam_a(String team_a) {
        this.team_a = team_a;
    }

    public String getTeam_b() {
        return team_b;
    }

    public void setTeam_b(String team_b) {
        this.team_b = team_b;
    }

    public SportType getSport() {
        return sport;
    }

    public void setSport(SportType sport) {
        this.sport = sport;
    }

   /* public List<MatchOdds> getMatchOdds() {
        return matchOdds;
    }*/

    /*@Override
    public String toString() {
        return "Match{" +
                "id=" + id +
                ", description='" + description + '\'' +
                ", match_date=" + match_date +
                ", team_a='" + team_a + '\'' +
                ", team_b='" + team_b + '\'' +
                ", sport=" + sport +
                ", matchOdd=" + matchOdds +
                '}';
    }*/
}
