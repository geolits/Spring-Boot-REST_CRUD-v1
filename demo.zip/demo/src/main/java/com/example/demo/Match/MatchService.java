package com.example.demo.Match;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

@Service //@Component Bean
public class MatchService {

    private final MatchRepository matchRepository;

    @Autowired
    public MatchService(MatchRepository matchRepository) {
        this.matchRepository = matchRepository;
    }

    public List<Match> getMatches(){
       return matchRepository.findAll();
    }

    public Match getMatchById(Long id){
        Optional<Match> matchOptional = matchRepository.findById(id);

        if (matchOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, String.format("Match with id %d not found", id));
        }

        return matchOptional.get();
    }

    public Match addNewMatch(Match match){
        System.out.println("The Match was added");
        return matchRepository.save(match);
    }


    public Match updateMatchById(Long id, Match match){
        Optional<Match> matchOptional = matchRepository.findById(id);

        if (matchOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, String.format("Match with id %d not found", id));
        }

        Match updatedMatch = matchOptional.get();

        updatedMatch.setDescription(match.getDescription());
        updatedMatch.setMatch_date(match.getMatch_date());
        updatedMatch.setSport(match.getSport());
        updatedMatch.setTeam_a(match.getTeam_a());
        updatedMatch.setTeam_b(match.getTeam_b());

        updatedMatch = matchRepository.save(updatedMatch);

        return updatedMatch;
    }

    public Match deleteMatchById(Long id){
        Optional<Match> matchOptional = matchRepository.findById(id);

        if (matchOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, String.format("Match with id %d not found", id));
        }

        matchRepository.deleteById(id);

        return matchOptional.get();
    }

    public Match updateMatchDescription(Long id, String description){

        Optional<Match> matchOptional = matchRepository.findById(id);

        if (matchOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, String.format("Match with id %d not found", id));
        }

        matchOptional.get().setDescription(description);
        matchRepository.save(matchOptional.get());

        return matchOptional.get();
    }

}
