package com.example.demo.Match;

public enum SportType {
   Football(1), Basketball(2);

   private Integer sportCode;

   private SportType(Integer code) {
      this.sportCode = code;
   }

   public Integer getSportCode() {
      return sportCode;
   }
}
