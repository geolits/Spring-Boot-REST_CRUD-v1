package com.example.demo.MatchOdds;

import com.example.demo.Match.Match;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import javax.persistence.*;


@Entity
@Table(name = "match_odd")
public class MatchOdd {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name="odd", precision=8, scale=2)
    private double odd;
    @Column(name="specifier")
    private String specifier;

    //@JsonBackReference
    @ManyToOne()
    @JoinColumn(name = "match_id", nullable=false)
    //@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
    //@JsonIdentityReference(alwaysAsId = true)
    //@JsonProperty("id")
    @JsonIdentityInfo(
            generator = ObjectIdGenerators.PropertyGenerator.class,
            property = "id")
    private Match match;

    public MatchOdd() {
    }

    public MatchOdd(double odd, String specifier, Match match) {
        this.odd = odd;
        this.specifier = specifier;
        this.match = match;
    }

   /* @Override
    public String toString() {
        return "MatchOdds{" +
                "id=" + id +
                ", odd=" + odd +
                ", specifier='" + specifier + '\'' +
                ", match_id=" + match.getId() +
                '}';
    }*/

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public double getOdd() {
        return odd;
    }

    public void setOdd(double odd) {
        this.odd = odd;
    }

    public String getSpecifier() {
        return specifier;
    }

    public void setSpecifier(String specifier) {
        this.specifier = specifier;
    }

    public Match getMatch() {
        return match;
    }

    public void setMatch(Match match) {
        this.match = match;
    }
}
