package com.example.demo.Match;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.time.Month;
import java.util.List;

@Configuration
public class MatchConfiguration {

    @Bean
    CommandLineRunner commandLineRunner(MatchRepository repository){
        return args -> {
           Match match1 =  new Match(
                    "description",
                    LocalDate.of(2022, Month.APRIL,17),
                    "PAO",
                    "OSFP",
                    SportType.Football
            );
            Match match2 = new Match(
                    "description",
                    LocalDate.of(2022, Month.APRIL,25),
                    "PAOK",
                    "IRAKLIS",
                    SportType.Football
            );

            repository.saveAll(List.of(match1, match2));

        };
    }
}
