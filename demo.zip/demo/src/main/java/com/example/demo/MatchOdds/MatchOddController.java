package com.example.demo.MatchOdds;

import com.example.demo.Match.Match;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "api/v1/matchOdds")
public class MatchOddController {

    private final MatchOddService matchOddService;

    @Autowired //DI
    public MatchOddController(MatchOddService matchOddService) {
        this.matchOddService = matchOddService;
    }

    @GetMapping
    public ResponseEntity<List<MatchOdd>> getMatchOdds(){
        List<MatchOdd> matchOddsList= matchOddService.getMatchOdds();
        return new ResponseEntity<>(matchOddsList, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MatchOdd> getMatchOddById(@PathVariable Long id){

        return  new ResponseEntity<>(matchOddService.getMatchOddById(id), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<MatchOdd> addNewMatch(@RequestBody MatchOdd matchOdd){
        return  new ResponseEntity<>(matchOddService.addNewMatchOdd(matchOdd), HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MatchOdd> updateMatchOdd(@PathVariable Long id, @RequestBody MatchOdd matchOdd){

        MatchOdd updatedOddMatch = matchOddService.updateMatchOddById(id, matchOdd);

        return  new ResponseEntity<>(updatedOddMatch, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public Map<String, Boolean> deleteMatchOdd(@PathVariable Long id){

        MatchOdd matchOdd = matchOddService.deleteMatchOddById(id);

        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }

    @PatchMapping("/{id}")
    public ResponseEntity<MatchOdd> updateMatchOddPartially(@PathVariable Long id, @RequestBody double oddPercentage) {

        MatchOdd matchOdd = matchOddService.updateMatchOddOddPercentage(id, oddPercentage);

        return new ResponseEntity<MatchOdd>(matchOdd, HttpStatus.OK);

    }

}
