package com.example.demo.Match;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.util.stream.Stream;

@Converter(autoApply = true)
public class SportTypeConverter implements AttributeConverter<SportType, Integer> {
    @Override
    public Integer convertToDatabaseColumn(SportType sportType) {
        if (sportType == null) {
            return null;
        }
        return sportType.getSportCode();
    }

    @Override
    public SportType convertToEntityAttribute(Integer sportCode) {
        if (sportCode == null) {
            return null;
        }

        return Stream.of(SportType.values())
                .filter(c -> c.getSportCode() == sportCode)
                .findFirst()
                .orElseThrow(IllegalArgumentException::new);
    }
}
